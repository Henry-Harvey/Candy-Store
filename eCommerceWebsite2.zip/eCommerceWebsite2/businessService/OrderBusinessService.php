<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../Autoloader.php';

class OrderBusinessService
{
    
    private $dbService;
    
    function __construct()
    {
        $this->dbService = new OrderDataService();
    }
    
    function newOrder($newOrder)
    {
        return $this->dbService->create($newOrder);
    }
    
    function getOrder($id)
    {
        return $this->dbService->read($id);
    }
    
    function getAllOrders()
    {
        return $this->dbService->readAll();
    }
    
    function editOrder($updatedOrder)
    {
        return $this->dbService->update($updatedOrder);
    }
    
    function deleteOrder($id)
    {
        return $this->dbService->delete($id);
    }
    
    function getAllForUser($user_id)
    {
        return $this->dbService->readAllForUser($user_id);
    }
    
    function getOrdersBetweenDates($startdate, $enddate)
    {
        return $this->dbService->readAllBetween($startdate, $enddate);
    }
    
    function getOrderDetailsForOrder($id){
        return $this->dbService->readDetails($id);
    }
    
    function checkout($order, $cart)
    {
        $db = new Database();
        $conn = $db->getConnection();
        
        $conn->autocommit(FALSE);
        $conn->begin_transaction();
        
        $order_id = $this->dbService->createSpecial($order, $conn);
        
        if ($order_id != -1) {
            
            $productBS = new ProductBusinessService();
            foreach ($cart->getItems() as $product_id => $qty) {
                $p = $productBS->getProduct($product_id);
                
                $orderDetails = new OrderDetails(0, $qty, $p->getName(), $p->getBrand(), $p->getPrice(), $product_id, $order_id);
                
                $ok = $this->dbService->createDetails($orderDetails, $conn);
                
                $cart->updateQty($product_id, 0);
            }
        } else {
            $ok = false;
        }
        
        if ($ok) {
            echo "order added!";
            $conn->commit();
            
            $cart->calcTotal();
            $_SESSION['cart'] = serialize($cart);
            $_SESSION['address'] = null;
        } else {
            echo "Rolled back";
            $conn->rollback();
        }
        
        $conn->close();
    }
    
}
 
 
