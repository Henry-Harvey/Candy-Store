<?php

class OrderDetails{
    
    private $id;
    private $quantity;
    private $current_name;
    private $current_brand;
    private $current_price;
    private $products_id;
    private $orders_id;
    
    public function __construct($id, $quantity, $current_name, $current_brand, $current_price, $products_id, $orders_id)
    {
       $this->id = $id;
       $this->quantity = $quantity; 
       $this->current_name = $current_name; 
       $this->current_brand = $current_brand; 
       $this->current_price = $current_price;   
       $this->products_id = $products_id;    
       $this->orders_id = $orders_id;    
    }
    
    public function getId()
    {
        return $this->id;
    }

    public function getQuantity()
    {
        return $this->quantity;
    }

    public function getCurrent_name()
    {
        return $this->current_name;
    }

    public function getCurrent_brand()
    {
        return $this->current_brand;
    }

    public function getCurrent_price()
    {
        return $this->current_price;
    }

    public function getProducts_id()
    {
        return $this->products_id;
    }

    public function getOrders_id()
    {
        return $this->orders_id;
    }

    public function setId($id)
    {
        $this->id = $id;
    }

    public function setQuantity($quantity)
    {
        $this->quantity = $quantity;
    }

    public function setCurrent_name($current_name)
    {
        $this->current_name = $current_name;
    }

    public function setCurrent_brand($current_brand)
    {
        $this->current_brand = $current_brand;
    }

    public function setCurrent_price($current_price)
    {
        $this->current_price = $current_price;
    }

    public function setProducts_id($products_id)
    {
        $this->products_id = $products_id;
    }

    public function setOrders_id($orders_id)
    {
        $this->orders_id = $orders_id;
    }
  
}

