<?php

class Product{
    
    private $id;
    private $name;
    private $brand;
    private $price;
    private $pic;
    
    function __construct($id, $name, $brand, $price, $pic){
        $this->id = $id;
        $this->name = $name;
        $this->brand = $brand;
        $this->price = $price;
        $this->pic = $pic;
    }
    
    public function getId()
    {
        return $this->id;
    }

    public function getName()
    {
        return $this->name;
    }

    public function getPrice()
    {
        return $this->price;
    }

    public function getBrand()
    {
        return $this->brand;
    }

    public function getPic()
    {
        return $this->pic;
    }

    public function setId($id)
    {
        $this->id = $id;
    }

    public function setName($name)
    {
        $this->name = $name;
    }

    public function setPrice($price)
    {
        $this->price = $price;
    }

    public function setBrand($brand)
    {
        $this->brand = $brand;
    }

    public function setPic($pic)
    {
        $this->pic = $pic;
    } 
    
}