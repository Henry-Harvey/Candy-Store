<?php

class CreditCard
{

    private $id;

    private $number;

    private $name;

    private $month;

    private $year;

    private $cvv;

    private $users_id;

    public function __construct($id, $number, $name, $month, $year, $cvv, $users_id)
    {
        $this->id = $id;
        $this->number = $number;
        $this->name = $name;
        $this->month = $month;
        $this->year = $year;
        $this->cvv = $cvv;
        $this->users_id = $users_id;
    }

    public function getId()
    {
        return $this->id;
    }

    public function setId($id)
    {
        $this->id = $id;
    }

    public function getNumber()
    {
        return $this->number;
    }

    public function getName()
    {
        return $this->name;
    }

    public function getMonth()
    {
        return $this->month;
    }

    public function getYear()
    {
        return $this->year;
    }

    public function getCvv()
    {
        return $this->cvv;
    }

    public function getUsers_id()
    {
        return $this->users_id;
    }

    public function setNumber($number)
    {
        $this->number = $number;
    }

    public function setName($name)
    {
        $this->name = $name;
    }

    public function setMonth($month)
    {
        $this->month = $month;
    }

    public function setYear($year)
    {
        $this->year = $year;
    }

    public function setCvv($cvv)
    {
        $this->cvv = $cvv;
    }

    public function setUsers_id($users_id)
    {
        $this->users_id = $users_id;
    }
}

