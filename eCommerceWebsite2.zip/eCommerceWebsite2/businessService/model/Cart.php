<?php

class Cart
{

    private $userid;

    // owner of the Cart
    private $items = array();

    // associative array of items in the Cart (prod_id=>qty, prod_id=>qty, prod_id=>qty)
    private $subtotals = array();

    // associative array of costs in the Cart (prod_id=>cost, prod_id=>cost, prod_id=>cost)
    private $total_price;

    // float, total cost of items in the Cart
    function __construct($userid)
    {
        $this->userid = $userid;
        $this->items = array();
        $this->subtotals = array();
        $this->total_price = 0;
    }

    function addItem($prod_id)
    {
        // item already in the cart, if so add 1
        if (array_key_exists($prod_id, $this->items)) {
            $this->items[$prod_id] += 1;
        } // cart empty
        else {
            $this->items = $this->items + array(
                $prod_id => 1
            );
        }
    }

    function updateQty($prod_id, $newQty)
    {
        // item exists
        if (array_key_exists($prod_id, $this->items)) {
            $this->items[$prod_id] = $newQty;
        } // item not in cart yet. Set its qty to $newQty
        else {
            $this->items = $this->items + array(
                $prod_id => $newQty
            );
        }
        if ($this->items[$prod_id] == 0) {
            unset($this->items[$prod_id]);
        }
    }

    function calcTotal()
    {
        // calculate subtotal for each product in the cart
        
        // calculate subtotal for all products in the cart
        $bs = new ProductBusinessService();
        
        // create an array to hold the subtotals
        $subtotals_array = array();
        $this->total_price = 0;
        
        foreach ($this->items as $item => $qty) {
            $product = $bs->getProduct($item);
            $product_subtotal = $product->getPrice() * $qty;
            $subtotals_array = $subtotals_array + array(
                $item => $product_subtotal
            );
            
            $this->total_price += $product_subtotal;
        }
        
        $this->subtotals = $subtotals_array;
    }

    public function getUserid()
    {
        return $this->userid;
    }

    public function getItems()
    {
        return $this->items;
    }

    public function getSubtotals()
    {
        return $this->subtotals;
    }

    public function getTotal_price()
    {
        return $this->total_price;
    }

    public function setUserid($userid)
    {
        $this->userid = $userid;
    }

    public function setItems($items)
    {
        $this->items = $items;
    }

    public function setSubtotals($subtotals)
    {
        $this->subtotals = $subtotals;
    }

    public function setTotal_price($total_price)
    {
        $this->total_price = $total_price;
    }
}