<?php

class Address{
    
    private $id;
    private $street;
    private $city;
    private $state;
    private $postal_code;
    private $users_id;
    
    function __construct($id, $street, $city, $state, $postal_code, $users_id){
        $this->id = $id;
        $this->street = $street;
        $this->city = $city;
        $this->state = $state;
        $this->postal_code = $postal_code;
        $this->users_id = $users_id;        
    }
    
    public function getId()
    {
        return $this->id;
    }

    public function getStreet()
    {
        return $this->street;
    }

    public function getCity()
    {
        return $this->city;
    }

    public function getState()
    {
        return $this->state;
    }

    public function getPostal_code()
    {
        return $this->postal_code;
    }

    public function getUsers_id()
    {
        return $this->users_id;
    }

    public function setId($id)
    {
        $this->id = $id;
    }

    public function setStreet($street)
    {
        $this->street = $street;
    }

    public function setCity($city)
    {
        $this->city = $city;
    }

    public function setState($state)
    {
        $this->state = $state;
    }

    public function setPostal_code($postalCode)
    {
        $this->postalCode = $postalCode;
    }

    public function setUsers_id($users_id)
    {
        $this->users_id = $users_id;
    }
    
    public function __toString()
    {
        return $this->street . ", " . $this->city . ", " . $this->state . ", " . $this->postal_code;
    }
  
}