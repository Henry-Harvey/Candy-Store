<?php

class Order{
    
    private $id;
    private $date;
    private $total_price;
    private $users_id;
    private $addresses_id;
    
    public function __construct($id, $date, $total_price, $users_id, $addresses_id)
    {
       $this->id = $id;
       $this->date = $date; 
       $this->total_price = $total_price; 
       $this->users_id = $users_id; 
       $this->addresses_id = $addresses_id;        
    }
    
    public function getId()
    {
        return $this->id;
    }

    public function getDate()
    {
        return $this->date;
    }

    public function getTotal_price()
    {
        return $this->total_price;
    }

    public function getUsers_id()
    {
        return $this->users_id;
    }

    public function getAddresses_id()
    {
        return $this->addresses_id;
    }

    public function setId($id)
    {
        $this->id = $id;
    }

    public function setDate($date)
    {
        $this->date = $date;
    }

    public function setTotal_price($total_price)
    {
        $this->total_price = $total_price;
    }

    public function setUsers_id($users_id)
    {
        $this->users_id = $users_id;
    }

    public function setAddresses_id($addresses_id)
    {
        $this->addresses_id = $addresses_id;
    }  
   
}

