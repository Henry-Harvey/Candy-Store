<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../Autoloader.php';

class AddressBusinessService
{

    private $dbService;

    function __construct()
    {
        $this->dbService = new AddressDataService();
    }

    function newAddress($newAddress)
    {
        return $this->dbService->create($newAddress);
    }

    function getAddress($id)
    {
        return $this->dbService->read($id);
    }

    function getAllAddresses()
    {
        return $this->dbService->readAll();
    }

    function editAddress($updatedAddress)
    {
        return $this->dbService->update($updatedAddress);
    }

    function deleteAddress($id)
    {
        return $this->dbService->delete($id);
    }

    function getAllAddressesForUser($user_id)
    {
        return $this->dbService->readAllForUser($user_id);
    }

    function setChechoutAddress($id)
    {
        return $this->dbService->setCheckoutAddress($id);
    }
}
 
 
