<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../Autoloader.php';

class ProductBusinessService
{

    private $dbService;

    function __construct()
    {
        $this->dbService = new ProductDataService();
    }

    function newProduct($newProduct)
    {
        return $this->dbService->create($newProduct);
    }

    function getProduct($id)
    {
        return $this->dbService->read($id);
    }

    function getAllProducts()
    {
        return $this->dbService->readAll();
    }

    function editProduct($updatedProduct)
    {
        return $this->dbService->update($updatedProduct);
    }

    function deleteProduct($id)
    {
        return $this->dbService->delete($id);
    }

    function getByProductName($n)
    {
        return $this->dbService->readByProductName($n);
    }
}
 
 
