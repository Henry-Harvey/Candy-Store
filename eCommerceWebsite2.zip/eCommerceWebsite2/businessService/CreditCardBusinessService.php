<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../Autoloader.php';

class CreditCardBusinessService
{

    private $dbService;

    function __construct()
    {
        $this->dbService = new CreditCardDataService();
    }

    function newCreditCard($newCreditCard)
    {
        return $this->dbService->create($newCreditCard);
    }

    function getCreditCard($id)
    {
        return $this->dbService->read($id);
    }

    function getAllCreditCards()
    {
        return $this->dbService->readAll();
    }

    function editCreditCard($updatedCreditCard)
    {
        return $this->dbService->update($updatedCreditCard);
    }

    function deleteCreditCard($id)
    {
        return $this->dbService->delete($id);
    }
    
    function getAllCreditCardsForUser($user_id){
        return $this->dbService->readAllForUser($user_id);
    }

    function authenticate($card)
    {
        return $this->dbService->authenticate($card);
    }
}
 
 
