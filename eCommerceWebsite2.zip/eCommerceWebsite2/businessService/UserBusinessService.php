<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../Autoloader.php';

class UserBusinessService
{

    private $dbService;

    function __construct()
    {
        $this->dbService = new UserDataService();
    }

    function newUser($newUser)
    {
        return $this->dbService->create($newUser);
    }

    function getUser($id)
    {
        return $this->dbService->read($id);
    }

    function getAllUsers()
    {
        return $this->dbService->readAll();
    }

    function editUser($updatedUser)
    {
        return $this->dbService->update($updatedUser);
    }

    function deleteUser($id)
    {
        return $this->dbService->delete($id);
    }

    function findByFirstNameWithAddress($n)
    {
        return $this->dbService->findByFirstNameWithAddress($n);
    }

    function findByLastNameWithAddress($n)
    {
        return $this->dbService->findByLastNameWithAddress($n);
    }

    function findByFirstName($n)
    {
        return $this->dbService->findByFirstName($n);
    }

    function login($username, $password)
    {
        return $this->dbService->login($username, $password);
    }
}
 
 
