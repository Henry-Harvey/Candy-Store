<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'header.php';
?>
<div class="container">
	<h1>Welcome to the Candy Shop</h1>

	<p>Browse through different types of candy and add them to your cart!
		To add more to the cart, use the update form within the "Qty" column.
		To remove a type of candy from the cart, simply set the qty to 0.
		Checkout by clicking the checkout button at the bottom of the Shopping
		Cart.</p>
</div>