<link rel="stylesheet" type="text/css"
	href="/eCommerceWebsite2/custom-styles.css">
<nav class="navbar navbar-expand-lg navbar navbar-dark bg-dark">
	<a class="navbar-brand" href="/eCommerceWebsite2/index.php">Candy Shop</a>
	<button class="navbar-toggler" type="button" data-toggle="collapse"
		data-target="#navbarSupportedContent"
		aria-controls="navbarSupportedContent" aria-expanded="false"
		aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
	</button>

	<div class="collapse navbar-collapse" id="navbarSupportedContent">
		<ul class="navbar-nav mr-auto">
			<li class="nav-item active"><a class="nav-link"
				href="/eCommerceWebsite2/index.php">Home <span class="sr-only">(current)</span></a>
			</li>

			<li class="nav-item"><a class="nav-link"
				href="/eCommerceWebsite2/presentation/views/showBrowseProducts.php">Browse</a></li>

			<li class="nav-item"><a class="nav-link"
				href="/eCommerceWebsite2/presentation/views/showProductSearchForm.php">Search
					Products</a></li>

			<li class="nav-item"><a class="nav-link"
				href="/eCommerceWebsite2/presentation/views/showCart.php">Shopping
					Cart</a></li>

			<li class="nav-item"><a class="nav-link"
				href="/eCommerceWebsite2/presentation/views/showOrders.php">My
					Orders</a></li>

	<?php
if (isset($_SESSION['role'])) {
    if ($_SESSION['role'] >= 2) {
        ?>

			<li class="nav-item"><a class="nav-link"
				href="/eCommerceWebsite2/presentation/views/showUserSearchForm.php">Search
					Users</a></li>
	<?php
    }
    if ($_SESSION['role'] >= 3) {
        ?>
			<li class="nav-item"><a class="nav-link"
				href="/eCommerceWebsite2/presentation/views/showNewUserForm.php">New
					User</a></li>

			<li class="nav-item"><a class="nav-link"
				href="/eCommerceWebsite2/presentation/views/showNewProductForm.php">New
					Product</a></li>
					
			<li class="nav-item"><a class="nav-link"
				href="/eCommerceWebsite2/presentation/views/showUploadImageForm.php">Image Upload</a></li>		
	<?php
    }
    if ($_SESSION['role'] >= 4) {
        ?>
			<li class="nav-item"><a class="nav-link"
				href="/eCommerceWebsite2/presentation/views/showAdminUsers.php">All
					Users</a></li>

			<li class="nav-item"><a class="nav-link"
				href="/eCommerceWebsite2/presentation/views/showAdminProducts.php">All
					Products</a></li>
			<li class="nav-item"><a class="nav-link"
				href="/eCommerceWebsite2/presentation/views/showSalesReportForm.php">Sales Report</a></li>
<?php
    }
}
?>
			
 <!-- <li class="nav-item">
        <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
      </li> -->

		</ul>

		<div class="loginForm" class="collapse navbar-collapse"
			id="navbarSupportedContent">
			<ul class="navbar-nav mr-auto">
    <?php
    if (isset($_SESSION['userid'])) {
        ?>
        		<li class="nav-item dropdown"><a
					class="nav-link dropdown-toggle" href="#" id="navbarDropdown"
					role="button" data-toggle="dropdown" aria-haspopup="true"
					aria-expanded="false"> My Account </a>
					<div class="dropdown-menu" aria-labelledby="navbarDropdown">
						<a class="dropdown-item"
							href="/eCommerceWebsite2/presentation/views/showManageAddresses.php">Manage
							Addresses</a>
						<div class="dropdown-divider"></div>
						<a class="dropdown-item"
							href="/eCommerceWebsite2/presentation/views/showManageCreditCards.php">Manage
							Credit Cards</a>
					</div></li>

				<li class="displayName">| <?php echo $_SESSION['name'];?> |</li>
			
			<!-- Admin Roles -->
				<?php
        if (isset($_SESSION['role'])) {
            if ($_SESSION['role'] == 2) {
                ?>
			<li class="displayName"><?php echo "Admin 1";?> |</li>
				<?php
            }
            if ($_SESSION['role'] == 3) {
                ?>
			<li class="displayName"><?php echo "Admin 2";?> |</li>
				<?php
            }
            if ($_SESSION['role'] == 4) {
                ?>
			<li class="displayName"><?php echo "Admin 3";?> |</li>
				<?php
            }
        }
        ?>

				<li class="nav-item"><a class="btn btn-dark"
					href="/eCommerceWebsite2/presentation/handlers/processLogout.php">Logout</a></li>
    <?php
    } else {
        ?>
       		    <li>
					<form
						action="/eCommerceWebsite2/presentation/handlers/processLogin.php"
						method="post">

						<label class="loginFontColor" for="username">Username: </label> <span
							class="input-span"><input type="text" name="username"></input></span>

						<label class="loginFontColor" for="password">Password: </label> <span
							class="input-span"><input type="password" name="password"></input></span>

						<div class="btn btn-dark">
							<button type="submit" name="login">Login</button>
						</div>
					</form>
				</li>
				<li>
					<form
						action="/eCommerceWebsite2/presentation/views/showRegisterForm.php">
						<div class="btn btn-dark">
							<button type="submit" name="Register">Register</button>
						</div>
					</form>
				</li>		
	<?php
    }
    ?>			
								
			</ul>
		</div>


		<!-- <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form> -->
	</div>
</nav>