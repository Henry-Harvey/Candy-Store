<head>
<link rel="stylesheet" type="text/css" href="../../custom-styles.css">
</head>

<div class="card-group">

<?php
for ($x = 0; $x < count($products); $x ++) {
    $p = $products[$x];
    ?>

<div class="col-12 col-sm-6 col-md-4 col-lg-3">

		<div class="card border-dark">
			<img class="card-img-top"
				src='../../pics/<?php echo $p->getPic();?>' alt="Card image cap">
			<div class="card-body">
				<h5 class="card-title"><?php echo $p->getName(); ?></h5>
				<p class="card-text"><?php echo $p->getBrand(); ?></p>
				<p class="card-text"><?php echo '$' . number_format($p->getPrice(), 2);?></p>

				<form action="../handlers/processAddToCart.php">
					<input type="hidden" name="id" value="<?php echo $p->getId();?>"> <input
						class="btn btn-dark" type="submit" value="Add to Cart">
				</form>
			</div>
		</div>
	</div>

<?php
}
?>

</div>