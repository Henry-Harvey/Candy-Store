<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "../../header.php";
require_once '../../Autoloader.php';

if (isset($_GET)) {
    $id = $_GET['id'];
    
    $bs = new AddressBusinessService();
    
    $address = $bs->getAddress($id);
    ?>
<div class="container">
	<h2>Edit Existing Address</h2>

	<form action="../handlers/processEditAddress.php">

		<div class="form-group">
			<input type="hidden" class="form-control" id="id"
				value="<?php echo $address->getId();?>" name="id">
		</div>

		<div class="form-group">
			<label for="street">Street</label> <input type="text"
				class="form-control" id="street"
				value="<?php echo $address->getStreet();?>" name="street">
		</div>

		<div class="form-group">
			<label for="city">City</label> <input type="text"
				class="form-control" id="city"
				value="<?php echo $address->getCity();?>" name="city">
		</div>

		<div class="form-group">
			<label for="state">State</label> <input type="text"
				class="form-control" id="state"
				value="<?php echo $address->getState();?>" name="state">
		</div>

		<div class="form-group">
			<label for="postal_code">Postal Code</label> <input type="text"
				class="form-control" id="postal_code"
				value="<?php echo $address->getPostal_code();?>" name="postal_code">
		</div>

		<button type="submit" class="btn btn-dark">Submit</button>

	</form>

</div>

<?php
} else {
    echo "Nothing submitted by the form<br>";
    echo "<a href='../views/adminProducts.php'>Return</a>";
}

?>