<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "../../header.php";
require_once '../../Autoloader.php';

if (isset($_GET)) {
    $id = $_GET['id'];
    
    $bs = new UserBusinessService();
    
    $user = $bs->getUser($id);
    
    ?>
<div class="container">
	<h2>Edit Existing User</h2>

	<form action="../handlers/processEditUser.php">

		<div class="form-group">
			<input type="hidden" class="form-control" id="id"
				value="<?php echo $user->getId()?>" name="id">
		</div>

		<div class="form-group">
			<label for="first_name">First Name</label> <input type="text"
				class="form-control" id="first_name"
				value="<?php echo $user->getFirst_name()?>" name="first_name">
		</div>

		<div class="form-group">
			<label for="last_name">Last Name</label> <input type="text"
				class="form-control" id="last_name"
				value="<?php echo $user->getLast_name()?>" name="last_name">
		</div>

		<div class="form-group">
			<label for="username">Username</label> <input type="text"
				class="form-control" id="username"
				value="<?php echo $user->getUsername()?>" name="username">
		</div>

		<div class="form-group">
			<label for="password">Password</label> <input type="text"
				class="form-control" id="password"
				value="<?php echo $user->getPassword()?>" name="password">
		</div>

		<div class="form-group">
			<label for="role">Role</label> <select class="form-control" id="role"
				name="role">
				<option
					<?php if($user->getRole() == 1){ echo "selected='selected'";}?>>1</option>
				<option
					<?php if($user->getRole() == 2){ echo "selected='selected'";}?>>2</option>
				<option
					<?php if($user->getRole() == 3){ echo "selected='selected'";}?>>3</option>
				<option
					<?php if($user->getRole() == 4){ echo "selected='selected'";}?>>4</option>
			</select>
		</div>

		<button type="submit" class="btn btn-dark">Submit</button>

	</form>

</div>

<?php
} else {
    echo "Nothing submitted by the form<br>";
    echo "<a href='../views/adminProducts.php'>Return</a>";
}

?>