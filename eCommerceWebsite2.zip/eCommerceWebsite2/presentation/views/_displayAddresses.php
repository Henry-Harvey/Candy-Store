<link rel="stylesheet" type="text/css" href="../../custom-styles.css">
<head>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
	integrity="sha256-pasqAKBDmFT4eHoN2ndd6lN370kFiGUFyTiUHWhU7k8="
	crossorigin="anonymous"></script>
<link rel="stylesheet" type="text/css"
	href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8"
	src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.js"></script>
</head>
<table id="addresses" class="display">

	<thead>

		<tr>
			<th>Edit</th>
			<th>Delete</th>
			<th>Street</th>
			<th>City</th>
			<th>State</th>
			<th>Postal Code</th>
		</tr>

	</thead>

	<tbody>

<?php
for ($x = 0; $x < count($user_addresses); $x ++) {
    
    $a = $user_addresses[$x];
    
    echo "<tr>";
    
    echo "<td><form action='showEditAddressForm.php'>
          <input type='hidden' name='id' value=" . $a->getId() . ">
          <input type='submit' value='Edit'>
          </form></td>";
    
    echo "<td><form action='../handlers/processDeleteAddress.php'>
          <input type='hidden' name='id' value=" . $a->getId() . ">
          <input type='submit' value='Delete'>
          </form></td>";
    
    echo "<td>" . $a->getStreet() . "</td>";
    echo "<td>" . $a->getCity() . "</td>";
    echo "<td>" . $a->getState() . "</td>";
    echo "<td>" . $a->getPostal_code() . "</td>";
}
?>

</tbody>

</table>

<script>
$(document).ready( function () {
    $('#addresses').DataTable();
} );
</script>