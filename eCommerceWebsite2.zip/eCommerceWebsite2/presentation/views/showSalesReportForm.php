<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../header.php';
require_once '../../Autoloader.php';

if (isset($_SESSION['role'])) {
    if ($_SESSION['role'] == 4) {
        ?>
<div class="container">
	<h2>Generate Sales Report</h2>

	<form action="../handlers/processSalesReport.php">

		<div class="form-group">
			<label for="startdate">Start Date</label> <input type="date"
				class="form-control" name="startdate">
		</div>

		<div class="form-group">
			<label for="enddate">End Date</label> <input type="date"
				class="form-control" name="enddate">
		</div>
		<button type="submit" class="btn btn-dark">Submit</button>

	</form>

</div>

<?php
    } else {
        echo "You must be a Level 2 admin to view this page. <br>";
        echo "<a href='../../index.php'>Return</a><br>";
    }
} else {
    echo "You must be logged in as a Level 2 admin to view this page. <br>";
    echo "<a href='../../index.php'>Return</a><br>";
}
?>