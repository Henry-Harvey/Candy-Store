<link rel="stylesheet" type="text/css" href="../../custom-styles.css">
<head>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
	integrity="sha256-pasqAKBDmFT4eHoN2ndd6lN370kFiGUFyTiUHWhU7k8="
	crossorigin="anonymous"></script>
<link rel="stylesheet" type="text/css"
	href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8"
	src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.js"></script>
</head>
<table id="products" class="display">

	<thead>

		<tr>
			<th>Pic</th>
			<th>ID</th>
			<th>Name</th>
			<th>Brand</th>
			<th>Price</th>
			<th>Quantity</th>
			<th>Subtotal</th>
		</tr>

	</thead>

	<tbody>

<?php
foreach ($c->getItems() as $product_id => $qty) {
    $p = $productBS->getProduct($product_id);
    echo "<tr>";
    
    echo "<td><img src= '../../pics/" . $p->getPic() . "'</td>";
    echo "<td>" . $p->getId() . "</td>";
    echo "<td>" . $p->getName() . "</td>";
    echo "<td>" . $p->getBrand() . "</td>";
    echo "<td> $" . number_format($p->getPrice(), 2) . "</td>";
    ?>
    <td>
    <form action="../handlers/processUpdateCartQty.php">
		<input type="hidden" name="id" value="<?php echo $p->getId();?>"> 
			<span class="input-group-text"> 
				<input class="form-control" type="text" name="qty" value="<?php echo $qty;?>"> 
				<input class="btn btn-dark" type="submit" name="submit" value="update">
    		</span>		
	</form>
	</td>
    <?php
    
    //echo "<td>" . $qty . "</td>";
    echo "<td> $" . number_format($qty * $p->getPrice(), 2) . "</td>";
}

?>

</tbody>

</table>

<h3>Total Price: $<?php echo number_format($c->getTotal_price(), 2);?></h3>
<a class='btn btn-dark' href="showBrowseProducts.php">Continue
	Shopping</a>
<a class='btn btn-dark' href="showCheckoutAddress.php">Checkout</a>

<script>
$(document).ready( function () {
    $('#products').DataTable();
} );
</script>