<link rel="stylesheet" type="text/css" href="../../custom-styles.css">
<head>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
	integrity="sha256-pasqAKBDmFT4eHoN2ndd6lN370kFiGUFyTiUHWhU7k8="
	crossorigin="anonymous"></script>
<link rel="stylesheet" type="text/css"
	href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8"
	src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.js"></script>
</head>
<table id="products" class="display">

	<thead>

		<tr>
			<th>Pic</th>
			<th>ID</th>
			<th>Name</th>
			<th>Brand</th>
			<th>Price</th>
		</tr>

	</thead>

	<tbody>

<?php
for ($x = 0; $x < count($products); $x ++) {
    
    $p = $products[$x];
    
    echo "<tr>";
    
    echo "<td><img src= '../../pics/" . $p->getPic() . "'</td>";
    echo "<td>" . $p->getId() . "</td>";
    echo "<td>" . $p->getName() . "</td>";
    echo "<td>" . $p->getPrice() . "</td>";
    echo "<td>" . $p->getBrand() . "</td>";
}
?>

</tbody>

</table>

<script>
$(document).ready( function () {
    $('#products').DataTable();
} );
</script>