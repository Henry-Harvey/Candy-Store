<link rel="stylesheet" type="text/css" href="../../custom-styles.css">
<head>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
	integrity="sha256-pasqAKBDmFT4eHoN2ndd6lN370kFiGUFyTiUHWhU7k8="
	crossorigin="anonymous"></script>
<link rel="stylesheet" type="text/css"
	href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8"
	src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.js"></script>
</head>
<table id="users" class="display">

	<thead>

		<tr>
			<th>ID</th>
			<th>First Name</th>
			<th>Last Name</th>
			<th>Street</th>
			<th>City</th>
			<th>State</th>
			<th>Postal Code</th>
		</tr>

	</thead>

	<tbody>

<?php
for ($x = 0; $x < count($users); $x ++) {
    
    $u = $users[$x];
    
    echo "<tr>";
    
    echo "<td>" . $u->getUser_id() . "</td>";
    echo "<td>" . $u->getFirst_name() . "</td>";
    echo "<td>" . $u->getLast_name() . "</td>";
    echo "<td>" . $u->getStreet() . "</td>";
    echo "<td>" . $u->getCity() . "</td>";
    echo "<td>" . $u->getState() . "</td>";
    echo "<td>" . $u->getPostal_code() . "</td>";
}
?>

</tbody>

</table>

<script>
$(document).ready( function () {
    $('#users').DataTable();
} );
</script>