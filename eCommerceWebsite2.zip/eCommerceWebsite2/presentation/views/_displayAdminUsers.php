<link rel="stylesheet" type="text/css" href="../../custom-styles.css">
<head>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
	integrity="sha256-pasqAKBDmFT4eHoN2ndd6lN370kFiGUFyTiUHWhU7k8="
	crossorigin="anonymous"></script>
<link rel="stylesheet" type="text/css"
	href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8"
	src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.js"></script>
</head>
<table id="users" class="display">

	<thead>

		<tr>
			<th>Edit</th>
			<th>Delete</th>
			<th>ID</th>
			<th>First Name</th>
			<th>Last Name</th>
			<th>Username</th>
			<th>Password</th>
			<th>Role</th>
		</tr>

	</thead>

	<tbody>

<?php
for ($x = 0; $x < count($users); $x ++) {
    
    $u = $users[$x];
    
    echo "<tr>";
    
    echo "<td><form action='showEditUserForm.php'>
          <input type='hidden' name='id' value=" . $u->getId() . ">
          <input type='submit' value='Edit'>
          </form></td>";
    
    echo "<td><form action='../handlers/processDeleteUser.php'>
          <input type='hidden' name='id' value=" . $u->getId() . ">
          <input type='submit' value='Delete'>
          </form></td>";
    
    echo "<td>" . $u->getId() . "</td>";
    echo "<td>" . $u->getFirst_name() . "</td>";
    echo "<td>" . $u->getLast_name() . "</td>";
    echo "<td>" . $u->getUsername() . "</td>";
    echo "<td>" . $u->getPassword() . "</td>";
    echo "<td>" . $u->getRole() . "</td>";
}
?>

</tbody>

</table>

<script>
$(document).ready( function () {
    $('#users').DataTable();
} );
</script>