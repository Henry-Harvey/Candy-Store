<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../header.php';
require_once '../../Autoloader.php';

if (isset($_SESSION['userid'])) {
    
    $bs = new AddressBusinessService();
    
    $user_addresses = $bs->getAllAddressesForUser($_SESSION['userid']);
    
    ?>
<div class="container">
	<h2>All Addresses</h2>

<?php
    
    ?> 
    <form action='showNewAddressForm.php'>
		<input type='submit' value='Add New Address'>
	</form>
        <?php
    require_once '_displayAddresses.php';
} else {
    echo "You must be logged in to view this page. <br>";
    echo "<a href='../../index.php'>Return</a><br>";
}
?>
</div>