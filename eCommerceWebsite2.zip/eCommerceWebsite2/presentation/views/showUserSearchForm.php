<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../header.php';
require_once '../../Autoloader.php';

if (isset($_SESSION['role'])) {
    if ($_SESSION['role'] >= 2) {
        ?>
<div class="container">
	<h2>User Search</h2>

	<form action="../handlers/processUserSearch.php">

		<div class="form-group">
			<label for="first_name">First Name</label> <input type="text"
				class="form-control" id="first_name" placeholder="First Name"
				name="first_name">
		</div>
		<button type="submit" class="btn btn-dark">Submit</button>

	</form>

	<form action="../handlers/processUserSearch.php">

		<div class="form-group">
			<label for="last_name">Last Name</label> <input type="text"
				class="form-control" id="last_name" placeholder="Last Name"
				name="last_name">
		</div>
		<button type="submit" class="btn btn-dark">Submit</button>

	</form>

</div>

<?php
    } else {
        echo "You must be a Level 2 admin to view this page. <br>";
        echo "<a href='../../index.php'>Return</a><br>";
    }
} else {
    echo "You must be logged in as a Level 2 admin to view this page. <br>";
    echo "<a href='../../index.php'>Return</a><br>";
}
?>