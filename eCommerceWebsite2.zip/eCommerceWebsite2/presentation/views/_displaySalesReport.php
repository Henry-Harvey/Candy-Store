<link rel="stylesheet" type="text/css" href="../../custom-styles.css">
<head>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
	integrity="sha256-pasqAKBDmFT4eHoN2ndd6lN370kFiGUFyTiUHWhU7k8="
	crossorigin="anonymous"></script>
<link rel="stylesheet" type="text/css"
	href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8"
	src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.js"></script>
</head>
<table id="products" class="display">

	<thead>

		<tr>
			<th>Order Info</th>
			<th>Name</th>
			<th>Date</th>
			<th>Total Price</th>
			<th>Address</th>
		</tr>

	</thead>

	<tbody>

<?php
foreach ($orders as $o) {
    echo "<tr>";
    
    echo "<td><form action='../views/showOneOrderDetails.php'>
          <input type='hidden' name='id' value=" . $o->getId() . ">
          <input type='submit' value='View'>
          </form></td>";   
    
    $u = $userBS->getUser($o->getUsers_id());
    echo "<td>" . $u->getFirst_name() . " " . $u->getLast_name() . "</td>";
    
    echo "<td>" . $o->getDate() . "</td>";
    echo "<td>$" . $o->getTotal_price() . "</td>";
    echo "<td>" . $addressBS->getAddress($o->getAddresses_id()) . "</td>";
}

?>

</tbody>

</table>

<script>
$(document).ready( function () {
    $('#products').DataTable();
} );
</script>