<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "../../header.php";
require_once '../../Autoloader.php';

if (isset($_GET)) {
    $id = $_GET['id'];
    
    $bs = new CreditCardBusinessService();
    
    $creditCard = $bs->getCreditCard($id);
    ?>
<div class="container">
	<h2>Edit Existing Credit Card</h2>

	<form action="../handlers/processEditCreditCard.php">

		<div class="form-group">
			<input type="hidden" class="form-control" id="id"
				value="<?php echo $creditCard->getId();?>" name="id">
		</div>

		<div class="form-group">
			<label for="number">Number</label> <input type="text"
				class="form-control" id="number"
				value="<?php echo $creditCard->getNumber();?>" name="number">
		</div>

		<div class="form-group">
			<label for="name">Name</label> <input type="text"
				class="form-control" id="name"
				value="<?php echo $creditCard->getName();?>" name="name">
		</div>

		<div class="form-group">
			<label for="month">Month</label> <input type="text"
				class="form-control" id="month"
				value="<?php echo $creditCard->getMonth();?>" name="month">
		</div>

		<div class="form-group">
			<label for="year">Year</label> <input type="text"
				class="form-control" id="year"
				value="<?php echo $creditCard->getYear();?>" name="year">
		</div>
		
		<div class="form-group">
			<label for="cvv">CVV</label> <input type="text"
				class="form-control" id="cvv"
				value="<?php echo $creditCard->getCvv();?>" name="cvv">
		</div>

		<button type="submit" class="btn btn-dark">Submit</button>

	</form>

</div>

<?php
} else {
    echo "Nothing submitted by the form<br>";
    echo "<a href='../views/adminProducts.php'>Return</a>";
}

?>