<link rel="stylesheet" type="text/css" href="../../custom-styles.css">
<head>
<style>

</style>
</head>

<div class="button-container">
	<form action='../views/showNewAddressForm.php'>
		<input type='submit' value='Add New Address'>
	</form>
	<form action='../views/showManageAddresses.php'>
		<input type='submit' value='Manage Addresses'>
	</form>
</div>

<br>

<table class="table">

	<thead>

		<tr>
			<th>Use</th>
			<th>Street</th>
			<th>City</th>
			<th>State</th>
			<th>Postal Code</th>
		</tr>

	</thead>

	<tbody>

<?php
foreach ($addresses as $a) {
    echo "<tr>";
    
    echo "<td><form action='../handlers/processPreCheckout.php'>
          <input type='hidden' name='id' value=" . $a->getId() . ">
          <input type='submit' value='Use'>
          </form></td>";
    
    echo "<td>" . $a->getStreet() . "</td>";
    echo "<td>" . $a->getCity() . "</td>";
    echo "<td>" . $a->getState() . "</td>";
    echo "<td>" . $a->getPostal_code() . "</td>";
}

?>

</tbody>

</table>