<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "../../header.php";
require_once '../../Autoloader.php';

if (isset($_SESSION['userid'])) {
?>
<div class="container">
	<h2>Add a New Credit Card</h2>

	<form action="../handlers/processNewCreditCard.php">

		<div class="form-group">
			<label for="number">Number</label> <input type="text"
				class="form-control" id="number" placeholder="0000000000000000"
				name="number">
		</div>

		<div class="form-group">
			<label for="name">Name</label> <input type="text"
				class="form-control" id="name" placeholder="First Last"
				name="name">
		</div>

		<div class="form-group">
			<label for="month">Month</label> <input type="text"
				class="form-control" id="month" placeholder="01"
				name="month">
		</div>

		<div class="form-group">
			<label for="year">Year</label> <input type="text"
				class="form-control" id="year" placeholder="19"
				name="year">
		</div>
		
		<div class="form-group">
			<label for="cvv">CVV</label> <input type="text"
				class="form-control" id="cvv" placeholder="000"
				name="cvv">
		</div>

		<button type="submit" class="btn btn-dark">Submit</button>

	</form>

</div>
<?php
} else {
    echo "You must be logged in to view this page. <br>";
    echo "<a href='../../index.php'>Return</a><br>";
}
?>