<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "../../header.php";
require_once '../../Autoloader.php';

if (isset($_GET)) {
    $id = $_GET['id'];
    
    $bs = new ProductBusinessService();
    
    $product = $bs->getProduct($id);
    
    ?>
<div class="container">
	<h2>Edit Existing Product</h2>

	<form action="../handlers/processEditProduct.php">

		<div class="form-group">
			<input type="hidden" class="form-control" id="id"
				value="<?php echo $product->getId()?>" name="id">
		</div>

		<div class="form-group">
			<label for="name">Name</label> <input type="text"
				class="form-control" id="name"
				value="<?php echo $product->getName()?>" name="name">
		</div>

		<div class="form-group">
			<label for="brand">Brand</label> <input type="text"
				class="form-control" id="brand"
				value="<?php echo $product->getBrand()?>" name="brand">
		</div>

		<div class="form-group">
			<label for="price">Price</label> <input type="text"
				class="form-control" id="price"
				value="<?php echo $product->getPrice()?>" name="price">
		</div>

		<div class="form-group">
			<label for="pic">Pic</label> <input type="text"
				class="form-control" id="pic"
				value="<?php echo $product->getPic()?>" name="pic">
		</div>

		<button type="submit" class="btn btn-dark">Submit</button>

	</form>

</div>

<?php
} else {
    echo "Nothing submitted by the form<br>";
    echo "<a href='../views/adminProducts.php'>Return</a>";
}

?>