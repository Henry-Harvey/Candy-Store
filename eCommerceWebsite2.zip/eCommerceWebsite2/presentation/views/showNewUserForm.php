<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "../../header.php";
require_once '../../Autoloader.php';

if (isset($_SESSION['role'])) {
    if ($_SESSION['role'] >= 3) {
        ?>
<div class="container">
	<h2>Create a New User</h2>

	<form action="../handlers/processNewUser.php">

		<div class="form-group">
			<label for="first_name">First Name</label> <input type="text"
				class="form-control" id="first_name" placeholder="First Name"
				name="first_name">
		</div>

		<div class="form-group">
			<label for="last_name">Last Name</label> <input type="text"
				class="form-control" id="last_name" placeholder="Last Name"
				name="last_name">
		</div>

		<div class="form-group">
			<label for="username">Username</label> <input type="text"
				class="form-control" id="username" placeholder="Username"
				name="username">
		</div>

		<div class="form-group">
			<label for="password">Password</label> <input type="text"
				class="form-control" id="password" placeholder="Password"
				name="password">
		</div>

		<div class="form-group">
			<label for="role">Role</label> <select class="form-control" id="role"
				name="role">
				<option>1</option>
				<option>2</option>
				<option>3</option>
				<option>4</option>
			</select>
		</div>

		<button type="submit" class="btn btn-dark">Submit</button>

	</form>

</div>
<?php
    } else {
        echo "You must be a Level 3 admin to view this page. <br>";
        echo "<a href='../../index.php'>Return</a><br>";
    }
} else {
    echo "You must be logged in as a Level 3 admin to view this page. <br>";
    echo "<a href='../../index.php'>Return</a><br>";
}
?>