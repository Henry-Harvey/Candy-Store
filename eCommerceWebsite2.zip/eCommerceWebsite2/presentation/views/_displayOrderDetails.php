<link rel="stylesheet" type="text/css" href="../../custom-styles.css">
<head>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
	integrity="sha256-pasqAKBDmFT4eHoN2ndd6lN370kFiGUFyTiUHWhU7k8="
	crossorigin="anonymous"></script>
<link rel="stylesheet" type="text/css"
	href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8"
	src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.js"></script>
</head>
<table id="order_details" class="display">

	<thead>

		<tr>
			<th>Details ID</th>
			<th>Quantity</th>
			<th>Name</th>
			<th>Brand</th>
			<th>Price</th>
		</tr>

	</thead>

	<tbody>

<?php
foreach ($order_details as $od) {
    echo "<tr>";
     
    echo "<td>" . $od->getId() . "</td>";
    echo "<td>" . $od->getQuantity() . "</td>";
    echo "<td>" . $od->getCurrent_name() . "</td>";
    echo "<td>" . $od->getCurrent_brand() . "</td>";
    echo "<td>$" . $od->getCurrent_price() . "</td>";
}

?>

</tbody>

</table>

<script>
$(document).ready( function () {
    $('#order_details').DataTable();
} );
</script>