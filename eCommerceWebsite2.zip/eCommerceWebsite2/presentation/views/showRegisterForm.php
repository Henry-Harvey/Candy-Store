<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "../../header.php";
require_once '../../Autoloader.php';

?>
<div class="container">
	<h2>Create a New User</h2>

	<form action="../handlers/processNewUser.php">

		<div class="form-group">
			<label for="first_name">First Name</label> <input type="text"
				class="form-control" id="first_name" placeholder="First Name"
				name="first_name">
		</div>

		<div class="form-group">
			<label for="last_name">Last Name</label> <input type="text"
				class="form-control" id="last_name" placeholder="Last Name"
				name="last_name">
		</div>

		<div class="form-group">
			<label for="username">Username</label> <input type="text"
				class="form-control" id="username" placeholder="Username"
				name="username">
		</div>

		<div class="form-group">
			<label for="password">Password</label> <input type="text"
				class="form-control" id="password" placeholder="Password"
				name="password">
		</div>
		
		<div class="form-group">
			<input type="hidden" class="form-control" id="role"
				value=1 name="role">
		</div>

		<button type="submit" class="btn btn-dark">Submit</button>

	</form>

</div>