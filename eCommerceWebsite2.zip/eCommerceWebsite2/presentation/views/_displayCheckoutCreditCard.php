<link rel="stylesheet" type="text/css" href="../../custom-styles.css">

<div class="button-container">
	<form action='../views/showNewCreditCardForm.php'>
		<input type='submit' value='Add New Credit Card'>
	</form>
	<form action='../views/showManageCreditCards.php'>
		<input type='submit' value='Manage Credit Cards'>
	</form>
</div>

<br>

<div class="container">
	<h2>Enter Credit Card Information</h2>
	<form action="../handlers/processCheckout.php">

		<div class="form-group">
			<label for="number">Card Number</label> <input type="text"
				class="form-control" id="number" placeholder="0000000000000000"
				name="number">
		</div>

		<div class="form-group">
			<label for="name">Name on Card</label> <input type="text"
				class="form-control" id="name"
				value="<?php echo $user->getFirst_name() . " " . $user->getLast_name()?>"
				name="name">
		</div>

		<div class="form-group" id="expiration">
			<label for="expiration">Expiration Date</label> <select name="month">
				<option value="01">01</option>
				<option value="02">02</option>
				<option value="03">03</option>
				<option value="04">04</option>
				<option value="05">05</option>
				<option value="06">06</option>
				<option value="07">07</option>
				<option value="08">08</option>
				<option value="09">09</option>
				<option value="10">10</option>
				<option value="11">11</option>
				<option value="12">12</option>
			</select> 
			<select name="year">
				<option value="19">19</option>
				<option value="20">20</option>
				<option value="21">21</option>
				<option value="22">22</option>
				<option value="23">23</option>
				<option value="24">24</option>
				<option value="25">25</option>
			</select>
		</div>

		<div class="form-group">
			<label for="cvv">CVV</label> <input type="text" class="form-control"
				id="cvv" placeholder="000" name="cvv">
		</div>

		<div class="form-group">
			<img class="creditcardimg" src="../../pics/visa.png" id="visa"> 
			<img class="creditcardimg" src="../../pics/mastercard.jpg" id="mastercard"> 
			<img class="creditcardimg" src="../../pics/discover.jpg" id="discover"> 
			<img class="creditcardimg" src="../../pics/amex.jpg" id="amex">
		</div>

		<button type="submit" class="btn btn-dark">Confirm</button>

	</form>

</div>