<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../header.php';
require_once '../../Autoloader.php';
?>

<div class="container">
	<h2>Shopping Cart</h2>
			
<?php
if (isset($_SESSION['userid'])) {
    $userid = $_SESSION['userid'];
} else {
    echo "You must be logged in to access cart<br>";
    exit();
}

$productBS = new ProductBusinessService();

if (isset($_SESSION['cart'])) {
    $c = unserialize($_SESSION['cart']);
    
    if(count($c->getItems()) == 0){
        echo "<h4>Nothing in the cart yet.</h4>";
        exit();
    }
} else {
    echo "<h4>Nothing in the cart yet.</h4>";
    exit();
}

if ($c->getUserid() != $userid) {
    echo "This cart does not belong to you";
    exit();
}

require_once "_displayCart.php";
?>

</div>