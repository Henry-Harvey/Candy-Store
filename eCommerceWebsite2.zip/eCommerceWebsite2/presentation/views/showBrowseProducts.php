<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../header.php';
require_once '../../Autoloader.php';

$bs = new ProductBusinessService();

$products = $bs->getAllProducts();

?>
<div class="container">
	<h2>Browse Products</h2>
<?php
require_once "_displayBrowseProductsCards.php";
?>
</div>