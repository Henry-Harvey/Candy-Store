<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../header.php';
require_once '../../Autoloader.php';

if (isset($_SESSION['userid'])) {
    
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
    }
    else{
        echo "No order given <br>";
        exit();
    }
     
    $orderBS = new OrderBusinessService();
    $order_details = $orderBS->getOrderDetailsForOrder($id);
    
    if($order_details == null){
        echo "No details found <br>";
        exit();
    }
    
    ?>
<div class="container">
	<h2>Order Details</h2>
	<h4>Order ID: <?php echo $id;?></h4>
<?php
    
    require_once '_displayOrderDetails.php';
    
} else {
    echo "You must be logged in to view this page. <br>";
    echo "<a href='../../index.php'>Return</a><br>";
}
?>
</div>