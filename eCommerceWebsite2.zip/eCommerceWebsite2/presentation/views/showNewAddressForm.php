<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "../../header.php";
require_once '../../Autoloader.php';

if (isset($_SESSION['userid'])) {
?>
<div class="container">
	<h2>Add a New Address</h2>

	<form action="../handlers/processNewAddress.php">

		<div class="form-group">
			<label for="street">Street</label> <input type="text"
				class="form-control" id="street" placeholder="Street"
				name="street">
		</div>

		<div class="form-group">
			<label for="city">City</label> <input type="text"
				class="form-control" id="city" placeholder="City"
				name="city">
		</div>

		<div class="form-group">
			<label for="state">State</label> <input type="text"
				class="form-control" id="state" placeholder="State"
				name="state">
		</div>

		<div class="form-group">
			<label for="postal_code">Postal Code</label> <input type="text"
				class="form-control" id="postal_code" placeholder="Postal Code"
				name="postal_code">
		</div>

		<button type="submit" class="btn btn-dark">Submit</button>

	</form>

</div>
<?php
} else {
    echo "You must be logged in to view this page. <br>";
    echo "<a href='../../index.php'>Return</a><br>";
}
?>