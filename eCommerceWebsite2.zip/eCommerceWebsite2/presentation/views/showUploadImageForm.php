<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "../../header.php";
require_once '../../Autoloader.php';

if (isset($_SESSION['role'])) {
    if ($_SESSION['role'] >= 3) {
        ?>
<h2>Upload an Image</h2>

<div class="container">
	<form action="../handlers/processUploadImage.php" method="post"
		enctype="multipart/form-data">
		<div class="form-group">
			Select image to upload: <input type="file" name="fileToUpload"
				id="fileToUpload"> <input type="submit" value="Upload Image"
				name="submit">
		</div>
	</form>
</div>

<br>


<h2>Gallery</h2>

<?php
        require_once '_displayAllImages.php';
    } else {
        echo "You must be a Level 3 admin to view this page. <br>";
        echo "<a href='../../index.php'>Return</a><br>";
    }
} else {
    echo "You must be logged in as a Level 3 admin to view this page. <br>";
    echo "<a href='../../index.php'>Return</a><br>";
}
?>