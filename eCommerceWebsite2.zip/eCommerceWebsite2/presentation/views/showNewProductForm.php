<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "../../header.php";
require_once '../../Autoloader.php';

if (isset($_SESSION['role'])) {
    if ($_SESSION['role'] >= 3) {
        ?>
<div class="container">
	<h2>Create a New Product</h2>

	<form action="../handlers/processNewProduct.php">

		<div class="form-group">
			<label for="name">Name</label> <input type="text"
				class="form-control" id="name" placeholder="Name" name="name">
		</div>

		<div class="form-group">
			<label for="brand">Brand</label> <input type="text"
				class="form-control" id="brand" placeholder="Brand" name="brand">
		</div>

		<div class="form-group">
			<label for="price">Price</label> <input type="text"
				class="form-control" id="price" placeholder="Price" name="price">
		</div>

		<div class="form-group">
			<label for="pic">Pic</label> <input type="text" class="form-control"
				id="pic" value="candy.jpg" name="pic">
		</div>

		<button type="submit" class="btn btn-dark">Submit</button>

	</form>

</div>
<?php
    } else {
        echo "You must be a Level 3 admin to view this page. <br>";
        echo "<a href='../../index.php'>Return</a><br>";
    }
} else {
    echo "You must be logged in as a Level 3 admin to view this page. <br>";
    echo "<a href='../../index.php'>Return</a><br>";
}
?>