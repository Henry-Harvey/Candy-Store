<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../header.php';
require_once '../../Autoloader.php';
?>

<div class="container">
	<h2>Checkout: Step 1</h2>
	
<?php
if (isset($_SESSION['userid'])) {
    $userid = $_SESSION['userid'];
} else {
    echo "You must be logged in to access checkout<br>";
    exit();
}

if (isset($_SESSION['cart'])) {
    $c = unserialize($_SESSION['cart']);
    
    if (count($c->getItems()) == 0) {
        echo "<h4>Nothing to check out.</h4>";
        exit();
    }
} else {
    echo "<h4>Nothing to check out.</h4>";
    exit();
}

if ($c->getUserid() != $userid) {
    echo "This checkout does not belong to you";
    exit();
}

$productBS = new ProductBusinessService();

$addressBS = new AddressBusinessService();
$addresses = $addressBS->getAllAddressesForUser($userid);

require_once "_displayOrderSummary.php";
require_once "_displayCheckoutAddress.php";
?>

</div>