<link rel="stylesheet" type="text/css" href="../../custom-styles.css">

<table class="table">

	<thead>

		<tr>
			<th>Image</th>
			<th>Name</th>
		</tr>

	</thead>

	<tbody>

<?php
foreach (glob('../../pics/*') as $file) {
    
    echo "<tr>";
    echo "<td><img src= '" . $file . "' class='bigImg'></td>";
    echo "<td>" . basename($file, '../../pics/') . "</td>";
}
?>

</tbody>

</table>