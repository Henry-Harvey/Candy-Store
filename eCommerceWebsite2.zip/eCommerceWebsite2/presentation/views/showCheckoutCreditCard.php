<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../header.php';
require_once '../../Autoloader.php';
?>

<div class="container">
	<h2>Checkout: Step 2</h2>
	
<?php
if (isset($_SESSION['userid'])) {
    $userid = $_SESSION['userid'];
} else {
    echo "You must be logged in to access checkout<br>";
    exit();
}

if (isset($_SESSION['cart'])) {
    $c = unserialize($_SESSION['cart']);
    
    if (count($c->getItems()) == 0) {
        echo "<h4>No items to check out.</h4>";
        exit();
    }
} else {
    echo "<h4>No items to check out.</h4>";
    exit();
}

if (!isset($_SESSION['address'])) {
    echo "Must complete address first<br>";
    echo "<a href='showCheckoutAddress.php'>Address</a>";
    exit();
}

if ($c->getUserid() != $userid) {
    echo "This checkout does not belong to you";
    exit();
}

$userBS = new UserBusinessService();
$user = $userBS->getUser($_SESSION['userid']);

$productBS = new ProductBusinessService();

require_once "_displayOrderSummary.php";
require_once "_displayCheckoutCreditCard.php";
?>

</div>