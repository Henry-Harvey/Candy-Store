<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../header.php';
require_once '../../Autoloader.php';

if (isset($_SESSION['role'])) {
    if ($_SESSION['role'] >= 4) {
        
        $bs = new UserBusinessService();
        
        $users = $bs->getAllUsers();
        
        ?>
<div class="container">
	<h2>All Users</h2>
<?php
        
        require_once '_displayAdminUsers.php';
    } else {
        echo "You must be a Level 4 admin to view this page. <br>";
        echo "<a href='../../index.php'>Return</a><br>";
    }
} else {
    echo "You must be logged in as a Level 4 admin to view this page. <br>";
    echo "<a href='../../index.php'>Return</a><br>";
}
?>
</div>