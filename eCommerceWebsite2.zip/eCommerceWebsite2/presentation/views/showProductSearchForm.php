<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../header.php';
require_once '../../Autoloader.php';
?>

<div class="container">
	<h2>Product Search</h2>

	<form action="../handlers/processProductSearch.php" class="form">

		<div class="form-group">

			<label for="name">Product Name</label> <input type="text"
				class="form-control" id="name" placeholder="Name" name="name">
		</div>
		<button type="submit" class="btn btn-dark">Submit</button>
		
	</form>

</div>