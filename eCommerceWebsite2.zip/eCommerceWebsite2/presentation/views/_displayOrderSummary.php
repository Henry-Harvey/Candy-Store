<link rel="stylesheet" type="text/css" href="../../custom-styles.css">
<body>
	<table class="table">

		<thead>

			<tr>
				<th>ID</th>
				<th>Name</th>
				<th>Brand</th>
				<th>Price</th>
				<th>Quantity</th>
				<th>Subtotal</th>
			</tr>

		</thead>

		<tbody>

<?php
foreach ($c->getItems() as $product_id => $qty) {
    $p = $productBS->getProduct($product_id);
    echo "<tr>";
    
    echo "<td>" . $p->getId() . "</td>";
    echo "<td>" . $p->getName() . "</td>";
    echo "<td>" . $p->getBrand() . "</td>";
    echo "<td> $" . number_format($p->getPrice(), 2) . "</td>";
    echo "<td>" . $qty . "</td>";
    echo "<td> $" . number_format($qty * $p->getPrice(), 2) . "</td>";
}

?>

</tbody>

	</table>

	<h4>Total Price: $<?php echo number_format($c->getTotal_price(), 2);?></h4>
	<br>
</body>
