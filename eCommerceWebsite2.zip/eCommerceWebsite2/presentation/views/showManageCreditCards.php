<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../header.php';
require_once '../../Autoloader.php';

if (isset($_SESSION['userid'])) {
    
    $bs = new CreditCardBusinessService();
    
    $user_creditCards = $bs->getAllCreditCardsForUser($_SESSION['userid']);
    
    ?>
<div class="container">
	<h2>All Credit Cards</h2>

<?php
    
    ?> 
    <form action='showNewCreditCardForm.php'>
		<input type='submit' value='Add New Credit Card'>
	</form>
        <?php
    require_once '_displayCreditCards.php';
} else {
    echo "You must be logged in to view this page. <br>";
    echo "<a href='../../index.php'>Return</a><br>";
}
?>
</div>