<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../header.php';
require_once '../../Autoloader.php';

if (isset($_SESSION['userid'])) {
    session_destroy();
    header("Location: ../../index.php");
} else {
    echo "<h3>You are already logged out <br>";
}

echo "<a href='../../index.php'>Return</a>";

?>
