<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../Autoloader.php';

if (!isset($_SESSION['userid'])) {
    echo "You must be logged in to access this page";
    exit();
}

if (isset($_GET)) {
    $number = addslashes($_GET['number']);
    $name = addslashes($_GET['name']);
    $month = addslashes($_GET['month']);
    $year = addslashes($_GET['year']);
    $cvv = addslashes($_GET['cvv']);
      
    $bs = new CreditCardBusinessService();
    $card = new CreditCard(0, $number, $name, $month, $year, $cvv, $_SESSION['userid']);
    
    if ($bs->authenticate($card)) {
        echo "Authenticated <br>";
    } else {
        echo "Card failed <br>";
        echo "<a href='../views/showCheckoutCreditCard.php'>Return</a>";
        exit;
    }
} else {
    echo "Nothing submitted by the form<br>";
}

echo "<a href='../views/showCheckout.php'>Return</a>";

?>

