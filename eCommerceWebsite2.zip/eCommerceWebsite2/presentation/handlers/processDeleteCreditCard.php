<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../header.php';
require_once '../../Autoloader.php';

if (isset($_GET)) {
    $id = $_GET['id'];
    
    $bs = new CreditCardBusinessService();
    
    if ($bs->deleteCreditCard($id)) {
        header("Location: ../views/showManageCreditCards.php");
    } else {
        echo "Nothing deleted<br>";
    }
} else {
    echo "Nothing submitted by the form<br>";
}

echo "<a href='../views/showAdminUsers.php'>Return</a>";

?>

