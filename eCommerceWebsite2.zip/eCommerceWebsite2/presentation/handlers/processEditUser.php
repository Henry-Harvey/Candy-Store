<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../header.php';
require_once '../../Autoloader.php';

if (isset($_GET)) {
    $id = $_GET['id'];
    $first_name = addslashes($_GET['first_name']);
    $last_name = addslashes($_GET['last_name']);
    $username = addslashes($_GET['username']);
    $password = addslashes($_GET['password']);
    $role = addslashes($_GET['role']);
    
    $bs = new UserBusinessService();
    $user = new User($id, $first_name, $last_name, $username, $password, $role);
    
    if ($bs->editUser($user)) {
        header("Location: ../views/showAdminUsers.php");
    } else {
        echo "Nothing updated<br>";
    }
} else {
    echo "Nothing submitted by the form<br>";
}

echo "<a href='../views/showAdminUsers.php'>Return</a>";

?>

