<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../header.php';
require_once '../../Autoloader.php';

if(!isset($_SESSION['userid'])){
    echo "You must be logged in to view this page";
    exit();
}

if (isset($_GET)) {
    $number = addslashes($_GET['number']);
    $name = addslashes($_GET['name']);
    $month = addslashes($_GET['month']);
    $year = addslashes($_GET['year']);
    $cvv = addslashes($_GET['cvv']);
    
    $bs = new CreditCardBusinessService();
    $creditCard = new CreditCard(0, $number, $name, $month, $year, $cvv, $_SESSION['userid']);
    
    if ($bs->newCreditCard($creditCard)) {
        header("Location: ../views/showManageCreditCards.php");
    } else {
        echo "Nothing inserted<br>";
    }
} else {
    echo "Nothing submitted by the form<br>";
}

echo "<a href='../../index.php'>Return</a>";

?>

