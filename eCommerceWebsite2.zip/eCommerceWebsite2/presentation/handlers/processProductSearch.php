<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../header.php';
require_once '../../Autoloader.php';

if (isset($_GET)) {
    $searchPhrase = addslashes($_GET['name']);
    
    $bs = new ProductBusinessService();
    
    $products = $bs->getByProductName($searchPhrase);
    
    ?>
<div class="container">
	<h2>Search Results</h2>
	Showing results for "<?php echo $searchPhrase;?>" <br> <a
		href="../../index.php">Return</a><br>
	
<?php
    if ($products) {
        require_once ('../views/_displayProductSearchResults.php');
    } else {
        echo "No results <br>";
    }
} else {
    echo "Nothing submitted by the form<br>";
}
?>

</div>