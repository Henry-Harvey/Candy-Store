<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../header.php';
require_once '../../Autoloader.php';

if (isset($_GET)) {
    $id = $_GET['id'];
    $name = addslashes($_GET['name']);
    $brand = addslashes($_GET['brand']);
    $price = addslashes($_GET['price']);
    $pic = addslashes($_GET['pic']);
    
    $bs = new ProductBusinessService();
    $product = new Product($id, $name, $brand, $price, $pic);
    
    if ($bs->editProduct($product)) {
        header("Location: ../views/showAdminProducts.php");
    } else {
        echo "Nothing updated<br>";
    }
} else {
    echo "Nothing submitted by the form<br>";
}

echo "<a href='../views/showAdminProducts.php'>Return</a>";

?>

