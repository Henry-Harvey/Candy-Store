<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../header.php';
require_once '../../Autoloader.php';

if (isset($_GET)) {
    $prodId = $_GET['id'];
    $qty = $_GET['qty'];
    
    if (isset($_SESSION['cart'])){
        $c = unserialize($_SESSION['cart']);
        $c->updateQty($prodId, $qty);
        $c->calcTotal();
        $_SESSION['cart'] = serialize($c);
        header("Location: ../views/showCart.php");
    }
} else {
    echo "Nothing submitted by the form<br>";
}

echo "<a href='../views/showCart.php'>Return</a>";