<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../header.php';
require_once '../../Autoloader.php';

if (isset($_POST)) {
    $username = addslashes($_POST['username']);
    $password = addslashes($_POST['password']);
    
    $bs = new UserBusinessService();
    
    if ($bs->login($username, $password)) {
        header("Location: ../../index.php");
    } else {
        echo "<h3>Login not successful<br>";
    }
       
}else {
    echo "Nothing submitted by the form<br>";
}

echo "<a href='../../index.php'>Return</a>";

?>
