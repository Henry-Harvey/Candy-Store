<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../header.php';
require_once '../../Autoloader.php';

if(!isset($_SESSION['userid'])){
    echo "You must be logged in to view this page";
    exit();
}

if (isset($_GET)) {
    $street = addslashes($_GET['street']);
    $city = addslashes($_GET['city']);
    $state = addslashes($_GET['state']);
    $postal_code = addslashes($_GET['postal_code']);
    
    $bs = new AddressBusinessService();
    $address = new Address(0, $street, $city, $state, $postal_code, $_SESSION['userid']);
    
    if ($bs->newAddress($address)) {
        header("Location: ../views/showManageAddresses.php");
    } else {
        echo "Nothing inserted<br>";
    }
} else {
    echo "Nothing submitted by the form<br>";
}

echo "<a href='../../index.php'>Return</a>";

?>

