<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../header.php';
require_once '../../Autoloader.php';

if (isset($_GET)) {
    // product ID
    $id = $_GET['id'];
    
    if (isset($_SESSION['userid'])) {
        
        if (isset($_SESSION['cart'])) {
            $c = unserialize($_SESSION['cart']);
        } else {
            $c = new Cart($_SESSION['userid']);
        }
        $c->addItem($id);
        $c->calcTotal();
        
        $_SESSION['cart'] = serialize($c);
        
        header("Location: ../views/showCart.php");
        
    } else {
        echo "You must be logged in to access cart<br>";
        echo "<a href='../views/showBrowseProducts.php'>Return</a>";
    }
} else {
    echo "Nothing submitted by the form<br>";
    echo "<a href='../views/showBrowseProducts.php'>Return</a>";
}