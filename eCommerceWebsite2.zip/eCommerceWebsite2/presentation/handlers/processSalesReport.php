<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../header.php';
require_once '../../Autoloader.php';

if (isset($_GET)) {
    if (isset($_GET['startdate'])) {
        $startdate = $_GET['startdate'];
    } else {
        echo "No start date entered. <br>";
        exit();
    }
    if (isset($_GET['enddate'])) {
        $enddate = $_GET['enddate'];
    } else {
        echo "No end date entered. <br>";
        exit();
    }
    
    $orderBS = new OrderBusinessService();
    $orders = $orderBS->getOrdersBetweenDates($startdate, $enddate);
    if ($orders == null) {
        echo "Sorry. No orders between those dates";
        exit();
    }
    
    $userBS = new UserBusinessService();
    
    $addressBS = new AddressBusinessService();
    require_once '../views/_displaySalesReport.php';
}
?>
