<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../header.php';
require_once '../../Autoloader.php';

if (isset($_GET)) {
    $bs = new UserBusinessService();
    if (isset($_GET['first_name'])) {
        $searchPhraseFirst = addslashes($_GET['first_name']);
        $users = $bs->findByFirstNameWithAddress($searchPhraseFirst);
        $searchPhrase = $searchPhraseFirst;
    } elseif (isset($_GET['last_name'])) {
        $searchPhraseLast = addslashes($_GET['last_name']);
        $users = $bs->findByLastNameWithAddress($searchPhraseLast);
        $searchPhrase = $searchPhraseLast;
    }
    ?>
<div class="container">
	<h2>Search Results</h2>
	Showing results for "<?php echo $searchPhrase;?>" <br> <a
		href="../views/showUserSearchForm.php">Return</a><br>
	
<?php
    if ($users) {
        require_once ('../views/_displayUserSearchResults.php');
    } else {
        echo "No results <br>";
    }
} else {
    echo "Nothing submitted by the form<br>";
}
?>

</div>