<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../header.php';
require_once '../../Autoloader.php';

if (!isset($_SESSION['userid'])) {
    echo "You must be logged in to acces this page";
    exit();
}

if (isset($_GET)) {
    $id = $_GET['id'];
    $number = addslashes($_GET['number']);
    $name = addslashes($_GET['name']);
    $month = addslashes($_GET['month']);
    $year = addslashes($_GET['year']);
    $cvv = addslashes($_GET['cvv']);
    
    $bs = new CreditCardBusinessService();
    
    $creditCard = new CreditCard($id, $number, $name, $month, $year, $cvv, $_SESSION['userid']);
    
    if ($bs->editCreditCard($creditCard)) {
        header("Location: ../views/showManageCreditCards.php");
    } else {
        echo "Nothing updated<br>";
    }
} else {
    echo "Nothing submitted by the form<br>";
}

echo "<a href='../views/showAdminUsers.php'>Return</a>";

?>

