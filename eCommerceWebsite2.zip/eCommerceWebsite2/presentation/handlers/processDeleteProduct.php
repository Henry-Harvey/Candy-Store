<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../header.php';
require_once '../../Autoloader.php';

if (isset($_GET)) {
    $id = $_GET['id'];
    
    $bs = new ProductBusinessService();
    
    if ($bs->deleteProduct($id)) {
        header("Location: ../views/showAdminProducts.php");
    } else {
        echo "Nothing deleted<br>";
    }
} else {
    echo "Nothing submitted by the form<br>";
}

echo "<a href='../views/showAdminProducts.php'>Return</a>";

?>

