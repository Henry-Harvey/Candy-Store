<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../header.php';
require_once '../../Autoloader.php';

require_once "_processAuthenticateCreditCard.php";

if (!isset($_SESSION['userid'])) {
    echo "You must be logged in to access checkout<br>";
    echo "<a href='../../index.php'>Return</a>";
}
if (!isset($_SESSION['cart'])) {
    echo "You must have items in your cart to access checkout<br>";
    echo "<a href='../views/showBrowseProducts.php'>Browse</a>";
}
if (!isset($_SESSION['address'])) {
    echo "You must complete your shipping information to access checkout<br>";
    echo "<a href='../views/showCheckoutAddress.php'>Address</a>";
}
    
    $cart = unserialize($_SESSION['cart']);    
    $orderBS = new OrderBusinessService();
    
    date_default_timezone_set('America/Phoenix');
    $date = date('Y/m/d H:i:s');
    
    $address = unserialize($_SESSION['address']);
    $address_id = $address->getId();
    
    // GET ADDRESS ID
    $order = new Order(0, $date, $cart->getTotal_price(), $_SESSION['userid'], $address_id);
    
    $orderBS->checkout($order, $cart);
       
    header("Location: ../views/showOrders.php");

