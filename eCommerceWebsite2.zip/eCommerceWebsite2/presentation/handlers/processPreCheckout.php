<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../header.php';
require_once '../../Autoloader.php';

if (isset($_SESSION['userid'])) {
    
    if (isset($_SESSION['cart'])) {
        $cart = unserialize($_SESSION['cart']);
    } else {
        $cart = new Cart($_SESSION['userid']);
    }
    
    if (isset($_GET)) {
        $id = $_GET['id'];
        $addressBS = new AddressBusinessService();
        if ($addressBS->setChechoutAddress($id)) {
            header("Location: ../views/showCheckoutCreditCard.php");
        } else {
            echo "Setting address session failed<br>";
            echo "<a href='../../index.php'>Return</a>";
        }
    } else {
        echo "Nothing submitted by the form<br>";
        echo "<a href='../../index.php'>Return</a>";
    }
} else {
    echo "You must be logged in to access cart<br>";
    echo "<a href='../../index.php'>Return</a>";
}
