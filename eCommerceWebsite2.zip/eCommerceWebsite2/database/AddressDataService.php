<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../Autoloader.php';

class AddressDataService implements DataServiceInterface
{

    function create($address)
    {
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("
        INSERT INTO addresses
        (STREET, CITY, STATE, POSTALCODE, USERS_ID)
        VALUES (?,?,?,?,?)");
        
        if (! $stmt) {
            echo "Something wrong in the binding process. sql error?";
            exit();
        }
        
        $street = $address->getStreet();
        $city = $address->getCity();
        $state = $address->getState();
        $postal_code = $address->getPostal_code();
        $users_id = $address->getUsers_id();
        
        $stmt->bind_param("ssssi", $street, $city, $state, $postal_code, $users_id);
        
        $stmt->execute();
        
        $connection->close();
        print_r($stmt);
        if ($stmt->affected_rows > 0) {
            return true;
        } else {
            return false;
        }
    }

    function read($id)
    {
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("
        SELECT * FROM addresses
        WHERE ID LIKE ?
        LIMIT 1");
        
        if (! $stmt) {
            echo "Something wrong in the binding process. sql error?";
            exit();
        }
        
        $stmt->bind_param("i", $id);
        
        $stmt->execute();
        
        $stmt->store_result();
        
        $stmt->bind_result($addressId, $street, $city, $state, $postalCode, $users_id);
        
        while ($address = $stmt->fetch()) {
            $a = new Address($addressId, $street, $city, $state, $postalCode, $users_id);
        }
        
        $connection->close();
        return $a;
    }

    function readAll()
    {
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("
        SELECT *
        FROM addresses");
        
        if (! $stmt) {
            echo "Something wrong in the binding process. sql error?";
            exit();
        }
        
        $stmt->execute();
        
        $stmt->store_result();
        
        $stmt->bind_result($address_id, $street, $city, $state, $postal_code, $users_id);
        
        $address_array = array();
        while ($address = $stmt->fetch()) {
            $a = new Address($address_id, $street, $city, $state, $postal_code, $users_id);
            array_push($address_array, $a);
        }
        
        $connection->close();
        return $address_array;
    }

    function update($address)
    {
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("
        UPDATE addresses
        SET STREET = ?, CITY = ?, STATE = ?, POSTALCODE = ?
        WHERE ID = ?
        LIMIT 1");
        
        if (! $stmt) {
            echo "Something wrong in the binding process. sql error?";
            exit();
        }
        
        $street = $address->getStreet();
        $city = $address->getCity();
        $state = $address->getState();
        $postal_code = $address->getPostal_code();
        $id = $address->getId();
        
        $stmt->bind_param("ssssi", $street, $city, $state, $postal_code, $id);
        
        $stmt->execute();
        
        $connection->close();
        if ($stmt->affected_rows > 0) {
            return true;
        } else {
            return false;
        }
    }

    function delete($id)
    {
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("
        DELETE FROM addresses
        WHERE ID = ?
        LIMIT 1");
        
        if (! $stmt) {
            echo "Something wrong in the binding process. sql error?";
            exit();
        }
        
        $stmt->bind_param("i", $id);
        
        $stmt->execute();
        
        $connection->close();
        if ($stmt->affected_rows > 0) {
            return true;
        } else {
            return false;
        }
    }

    function readAllForUser($user_id)
    {
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("
        SELECT * FROM addresses
        WHERE USERS_ID LIKE ?");
        
        if (! $stmt) {
            echo "Something wrong in the binding process. sql error?";
            exit();
        }
        
        $stmt->bind_param("i", $user_id);
        
        $stmt->execute();
        
        $stmt->store_result();
        
        $stmt->bind_result($address_id, $street, $city, $state, $postalCode, $users_id);
        
        $addresses = array();
        while ($address = $stmt->fetch()) {
            $a = new Address($address_id, $street, $city, $state, $postalCode, $users_id);
            array_push($addresses, $a);
        }
        
        $connection->close();
        return $addresses;
    }

    function setCheckoutAddress($id)
    {
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("
        SELECT * FROM addresses
        WHERE ID LIKE ?
        LIMIT 1");
        
        if (! $stmt) {
            echo "Something wrong in the binding process. sql error?";
            exit();
        }
        
        $stmt->bind_param("i", $id);
        
        $stmt->execute();
        
        $stmt->store_result();
        
        $stmt->bind_result($addressId, $street, $city, $state, $postalCode, $users_id);
        
        while ($address = $stmt->fetch()) {
            $a = new Address($addressId, $street, $city, $state, $postalCode, $users_id);
        }
        
        $connection->close();
        if ($stmt->num_rows == 1) {
            $_SESSION['address'] = serialize($a);
            return true;
        } else {
            return false;
        }
    }
}