<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../Autoloader.php';

class ProductDataService implements DataServiceInterface
{

    function create($product)
    {
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("
        INSERT INTO products
        (PRODUCTNAME, PRODUCTBRAND, PRICE, PIC)
        VALUES (?,?,?,?)");
        
        if (! $stmt) {
            echo "Something wrong in the binding process. sql error?";
            exit();
        }
        
        $n = $product->getName();
        $b = $product->getBrand();
        $pr = $product->getPrice();
        $pi = $product->getPic();
        
        $stmt->bind_param("ssds", $n, $b, $pr, $pi);
        
        $stmt->execute();
        
        if ($stmt->affected_rows > 0) {
            return true;
        } else {
            return false;
        }
    }

    function read($id)
    {
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("
        SELECT *
        FROM products
        WHERE ID LIKE ?");
        
        if (! $stmt) {
            echo "Something wrong in the binding process. sql error?";
            exit();
        }
        
        // $like_id = "%" . $n . "%";
        $stmt->bind_param("i", $id);
        
        $stmt->execute();
        
        $stmt->store_result();
        
        $stmt->bind_result($product_id, $name, $brand, $price, $pic);
        
        while ($product = $stmt->fetch()) {
            $p = new Product($product_id, $name, $brand, $price, $pic);
        }
        return $p;
    }

    function readAll()
    {
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("
        SELECT *
        FROM products");
        
        if (! $stmt) {
            echo "Something wrong in the binding process. sql error?";
            exit();
        }
        
        $stmt->execute();
        
        $stmt->store_result();
        
        $stmt->bind_result($id, $name, $brand, $price, $pic);
        
        $product_array = array();
        while ($product = $stmt->fetch()) {
            $p = new Product($id, $name, $brand, $price, $pic);
            array_push($product_array, $p);
        }
        
        $connection->close();
        return $product_array;
    }

    function update($product)
    {
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("
        UPDATE products
        SET PRODUCTNAME = ?, PRODUCTBRAND = ?, PRICE = ?, PIC = ?
        WHERE ID = ?
        LIMIT 1");
        
        if (! $stmt) {
            echo "Something wrong in the binding process. sql error?";
            exit();
        }
        
        $n = $product->getName();
        $b = $product->getBrand();
        $pr = $product->getPrice();
        $pi = $product->getPic();
        $id = $product->getId();
        
        $stmt->bind_param("ssdsi", $n, $b, $pr, $pi, $id);
        
        $stmt->execute();
        
        if ($stmt->affected_rows > 0) {
            return true;
        } else {
            return false;
        }
    }

    function delete($id)
    {
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("
        DELETE FROM products
        WHERE ID = ?
        LIMIT 1");
        
        if (! $stmt) {
            echo "Something wrong in the binding process. sql error?";
            exit();
        }
        
        $stmt->bind_param("i", $id);
        
        $stmt->execute();
        
        if ($stmt->affected_rows > 0) {
            return true;
        } else {
            return false;
        }
    }

    function readByProductName($n)
    {
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("SELECT ID, PRODUCTNAME, PRODUCTBRAND, PRICE, PIC 
        FROM products 
        WHERE PRODUCTNAME LIKE ?");
        
        if (! $stmt) {
            echo "Something wrong in the binding process. sql error?";
            exit();
        }
        
        $like_n = "%" . $n . "%";
        $stmt->bind_param("s", $like_n);
        
        $stmt->execute();
        
        $stmt->store_result();
        
        $stmt->bind_result($id, $name, $brand, $price, $pic);
        
        $product_array = array();
        while ($product = $stmt->fetch()) {
            $p = new Product($id, $name, $brand, $price, $pic);
            array_push($product_array, $p);
        }
        return $product_array;
    }
}