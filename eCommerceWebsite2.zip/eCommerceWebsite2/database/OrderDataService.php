<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../Autoloader.php';

class OrderDataService implements DataServiceInterface
{
    
    function createSpecial($order, $connection)
    {
        $stmt = $connection->prepare("
        INSERT INTO orders
        (DATE, TOTALPRICE, USERS_ID, ADDRESSES_ID)
        VALUES (?,?,?,?)");
        
        if (! $stmt) {
            echo "Something wrong in the binding process. sql error?";
            exit();
        }
        
        $date = $order->getDate();
        $total_price = $order->getTotal_price();
        $users_id = $order->getUsers_id();
        $addresses_id = $order->getAddresses_id();
        
        $stmt->bind_param("sdii", $date, $total_price, $users_id, $addresses_id);
        
        $stmt->execute();
        
        // $connection->close();
        if ($stmt->affected_rows > 0) {
            return $connection->insert_id;
        } else {
            return - 1;
        }
    }

    function read($id)
    {
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("
        SELECT * FROM orders
        WHERE ID LIKE ?
        LIMIT 1");
        
        if (! $stmt) {
            echo "Something wrong in the binding process. sql error?";
            exit();
        }
        
        $stmt->bind_param("i", $id);
        
        $stmt->execute();
        
        $stmt->store_result();
        
        $stmt->bind_result($orderid, $date, $total_price, $users_id, $addresses_id);
        
        while ($order = $stmt->fetch()) {
            $o = new Order($orderid, $date, $total_price, $users_id, $addresses_id);
        }
        
        $connection->close();
        return $o;
    }

    function readAll()
    {
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("
        SELECT *
        FROM orders");
        
        if (! $stmt) {
            echo "Something wrong in the binding process. sql error?";
            exit();
        }
        
        $stmt->execute();
        
        $stmt->store_result();
        
        $stmt->bind_result($orderid, $date, $total_price, $users_id, $addresses_id);
        
        $orders = array();
        while ($order = $stmt->fetch()) {
            $o = new Order($orderid, $date, $total_price, $users_id, $addresses_id);
            array_push($orders, $o);
        }
        
        $connection->close();
        return $orders;
    }

    function update($order)
    {
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("
        UPDATE orders
        SET DATE = ?, TOTALPRICE = ?
        WHERE ID = ?
        LIMIT 1");
        
        if (! $stmt) {
            echo "Something wrong in the binding process. sql error?";
            exit();
        }
        
        $date = $order->getDate();
        $total_price = $order->getTotal_price();
        
        $stmt->bind_param("ssi", $date, $total_price);
        
        $stmt->execute();
        
        $connection->close();
        if ($stmt->affected_rows > 0) {
            return true;
        } else {
            return false;
        }
    }

    function delete($id)
    {
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("
        DELETE FROM orders
        WHERE ID = ?
        LIMIT 1");
        
        if (! $stmt) {
            echo "Something wrong in the binding process. sql error?";
            exit();
        }
        
        $stmt->bind_param("i", $id);
        
        $stmt->execute();
        
        $connection->close();
        if ($stmt->affected_rows > 0) {
            return true;
        } else {
            return false;
        }
    }

    function createDetails($orderDetails, $connection)
    {
        $stmt = $connection->prepare("
        INSERT INTO orderdetails
        (QUANTITY, CURRENTNAME, CURRENTBRAND, CURRENTPRICE, PRODUCTS_ID, ORDERS_ID)
        VALUES (?,?,?,?,?,?)");
        
        if (! $stmt) {
            echo "Something wrong in the binding process. sql error?";
            exit();
        }
        
        $quantity = $orderDetails->getQuantity();
        $current_name = $orderDetails->getCurrent_name();
        $current_brand = $orderDetails->getCurrent_brand();
        $current_price = $orderDetails->getCurrent_price();
        $products_id = $orderDetails->getProducts_id();
        $orders_id = $orderDetails->getOrders_id();
        
        $stmt->bind_param("issdii", $quantity, $current_name, $current_brand, $current_price, $products_id, $orders_id);
        
        $stmt->execute();
        
        // $connection->close();
        if ($stmt->affected_rows > 0) {
            return true;
        } else {
            return false;
        }
    }

    function readAllForUser($user_id)
    {
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("
        SELECT * FROM orders
        WHERE USERS_ID LIKE ?");
        
        if (! $stmt) {
            echo "Something wrong in the binding process. sql error?";
            exit();
        }
        
        $stmt->bind_param("i", $user_id);
        
        $stmt->execute();
        
        $stmt->store_result();
        
        $stmt->bind_result($orderid, $date, $total_price, $users_id, $addresses_id);
        
        $orders = array();
        while ($order = $stmt->fetch()) {
            $o = new Order($orderid, $date, $total_price, $users_id, $addresses_id);
            array_push($orders, $o);
        }
        
        $connection->close();
        return $orders;
    }
    
    function readAllBetween($startdate, $enddate)
    {
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("
        SELECT * FROM orders
        WHERE DATE BETWEEN ? AND ?");
        
        if (! $stmt) {
            echo "Something wrong in the binding process. sql error?";
            exit();
        }
        
        $stmt->bind_param("ss", $startdate, $enddate);
        
        $stmt->execute();
        
        $stmt->store_result();
        
        $stmt->bind_result($orderid, $date, $total_price, $users_id, $addresses_id);
        
        $orders = array();
        while ($order = $stmt->fetch()) {
            $o = new Order($orderid, $date, $total_price, $users_id, $addresses_id);
            array_push($orders, $o);
        }
        
        $connection->close();
        return $orders;
    }
    
    function readDetails($orderid){
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("
        SELECT * FROM orderdetails
        WHERE ORDERS_ID LIKE ?");
        
        if (! $stmt) {
            echo "Something wrong in the binding process. sql error?";
            exit();
        }
        
        $stmt->bind_param("i", $orderid);
        
        $stmt->execute();
        
        $stmt->store_result();
        
        $stmt->bind_result($id, $quantity, $name, $brand, $price, $products_id, $orders_id);
        
        $order_details = array();
        while ($order = $stmt->fetch()) {
            $od = new OrderDetails($id, $quantity, $name, $brand, $price, $products_id, $orders_id);
            array_push($order_details, $od);
        }
        
        $connection->close();
        return $order_details;
    }
    
    function create($order)
    {
        return null;
    }
}