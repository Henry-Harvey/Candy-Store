<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../Autoloader.php';

class CreditCardDataService implements DataServiceInterface
{
        
    function create($creditCard)
    {
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("
        INSERT INTO creditcards
        (NUMBER, NAME, MONTH, YEAR, CVV, USERS_ID)
        VALUES (?,?,?,?,?,?)");
        
        if (! $stmt) {
            echo "Something wrong in the binding process. sql error?";
            exit();
        }

        $number = $creditCard->getNumber();
        $name = $creditCard->getName();
        $month = $creditCard->getMonth();
        $year = $creditCard->getYear();
        $cvv = $creditCard->getCvv();
        $users_id = $creditCard->getUsers_id();
        
        $stmt->bind_param("sssssi", $number, $name, $month, $year, $cvv, $users_id);
        
        $stmt->execute();
        
        $connection->close();
        if ($stmt->affected_rows > 0) {
            return true;
        } else {
            return false;
        }
    }
    
    function read($id)
    {
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("
        SELECT * FROM creditcards
        WHERE ID LIKE ?
        LIMIT 1");
        
        if (! $stmt) {
            echo "Something wrong in the binding process. sql error?";
            exit();
        }
        
        $stmt->bind_param("i", $id);
        
        $stmt->execute();
        
        $stmt->store_result();
        
        $stmt->bind_result($cc_id, $number, $name, $month, $year, $cvv, $users_id);
        
        while ($creditCard = $stmt->fetch()) {
            $c = new CreditCard($cc_id, $number, $name, $month, $year, $cvv, $users_id);
        }
        
        $connection->close();
        return $c;
    }
    
    function readAll()
    {
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("
        SELECT *
        FROM creditcards");
        
        if (! $stmt) {
            echo "Something wrong in the binding process. sql error?";
            exit();
        }
        
        $stmt->execute();
        
        $stmt->store_result();
        
        $stmt->bind_result($id, $number, $name, $month, $year, $cvv, $users_id);
        
        $creditCard_array = array();
        while ($address = $stmt->fetch()) {
            $c = new CreditCard($id, $number, $name, $month, $year, $cvv, $users_id);
            array_push($creditCard_array, $c);
        }
        
        $connection->close();
        return $creditCard_array;
    }   
    
    function update($creditCard)
    {
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("
        UPDATE creditcards
        SET NUMBER = ?, NAME = ?, MONTH = ?, YEAR = ?, CVV = ?
        WHERE ID = ?
        LIMIT 1");
        
        if (! $stmt) {
            echo "Something wrong in the binding process. sql error?";
            exit();
        }
        
        $number = $creditCard->getNumber();
        $name = $creditCard->getName();
        $month = $creditCard->getMonth();
        $year = $creditCard->getYear();
        $cvv = $creditCard->getCvv();
        $id = $creditCard->getId();
        
        $stmt->bind_param("sssssi", $number, $name, $month, $year, $cvv, $id);
        
        $stmt->execute();
        
        $connection->close();
        if ($stmt->affected_rows > 0) {
            return true;
        } else {
            return false;
        }
    }
    
    function delete($id)
    {
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("
        DELETE FROM creditcards
        WHERE ID = ?
        LIMIT 1");
        
        if (! $stmt) {
            echo "Something wrong in the binding process. sql error?";
            exit();
        }
        
        $stmt->bind_param("i", $id);
        
        $stmt->execute();
        
        $connection->close();
        if ($stmt->affected_rows > 0) {
            return true;
        } else {
            return false;
        }
    }
    
    function authenticate($card)
    {
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("
        SELECT *
        FROM creditcards
        WHERE NUMBER = ? AND NAME = ? AND MONTH = ? AND YEAR = ? AND CVV = ? AND USERS_ID = ?
        LIMIT 1");
        
        if (! $stmt) {
            echo "Something wrong in the binding process. sql error?";
            exit();
        }
        
        $number = $card->getNumber();
        $name = $card->getName();
        $month = $card->getMonth();
        $year = $card->getYear();
        $cvv = $card->getCvv();
        $users_id = $card->getUsers_id();
        
        $stmt->bind_param("sssssi", $number, $name, $month, $year, $cvv, $users_id);
        
        $stmt->execute();
        
        $stmt->store_result();
        
        /* $stmt->bind_result($id, $number, $name, $month, $year, $cvv, $user_id);
        
        while ($user = $stmt->fetch()) {
            $card = new CreditCard($id, $number, $name, $month, $year, $cvv);
        } */
        
        $connection->close();
        if ($stmt->num_rows == 1) {
            return true;           
        } else {
            return false;
        }
    }
    
    function readAllForUser($user_id){
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("
        SELECT * FROM creditcards
        WHERE USERS_ID LIKE ?");
        
        if (! $stmt) {
            echo "Something wrong in the binding process. sql error?";
            exit();
        }
        
        $stmt->bind_param("i", $user_id);
        
        $stmt->execute();
        
        $stmt->store_result();
        
        $stmt->bind_result($id, $number, $name, $month, $year, $cvv, $users_id);
        
        $creditCards = array();
        while ($address = $stmt->fetch()) {
            $c = new CreditCard($id, $number, $name, $month, $year, $cvv, $users_id);
            array_push($creditCards, $c);
        }
        
        $connection->close();
        return $creditCards;
    }

}